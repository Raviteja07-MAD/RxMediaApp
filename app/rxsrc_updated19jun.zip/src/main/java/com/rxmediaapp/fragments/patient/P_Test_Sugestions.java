package com.rxmediaapp.fragments.patient;

import android.app.Activity;
import android.app.DatePickerDialog;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ListPopupWindow;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.rxmediaapp.R;
import com.rxmediaapp.Sidemenu.SideMenu;
import com.rxmediaapp.customadapter.HashMapRecycleviewadapter;
import com.rxmediaapp.customfonts.CustomEditText;
import com.rxmediaapp.serviceparsing.APIInterface;
import com.rxmediaapp.serviceparsing.CustomProgressbar;
import com.rxmediaapp.serviceparsing.InterNetChecker;
import com.rxmediaapp.serviceparsing.JsonParsing;
import com.rxmediaapp.serviceparsing.RetrofitInstance;
import com.rxmediaapp.storedobjects.StoredObjects;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.HashMap;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;

public class P_Test_Sugestions extends Fragment {

    ImageView backbtn_img;
    TextView title_txt;
    CustomEditText docas_frmdate_edtx,docas_todate_edtx,patient_frmdate_edtx,patient_todate_edtx,p_type_edtx;
    static RecyclerView p_test_recyler;
    public static HashMapRecycleviewadapter adapter;
    public static TextView nodatavailable_txt;

    public static ArrayList<HashMap<String, String>> data_list = new ArrayList<>();
    public static ArrayList<HashMap<String, String>> dummy_list = new ArrayList<>();

    DatePickerDialog datePickerDialog;
    int year;
    int month;
    int dayOfMonth;
    Calendar calendar;
    int pagecount=1,totalpages=0;
    String recordsperpage="10";
    Button d_sbmt_btn,d_cancel_btn;


    String search_text="",from_date="",to_date="";
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate( R.layout.patient_test_sugestions,null,false );
        StoredObjects.page_type="patient_test_sugestions";

        SideMenu.updatemenu(StoredObjects.page_type);

        initilization(v);
        pagecount=1;
        serviceCalling();
        return v;
    }

    private void initilization(View v) {

        backbtn_img = v.findViewById(R.id.backbtn_img);
        title_txt = v.findViewById(R.id.title_txt);
        p_test_recyler = v.findViewById(R.id.p_test_recyler);
        nodatavailable_txt=v.findViewById(R.id.nodatavailable_txt);
        patient_frmdate_edtx=v.findViewById(R.id.patient_frmdate_edtx);
        patient_todate_edtx=v.findViewById(R.id.patient_todate_edtx);
        docas_frmdate_edtx=v.findViewById(R.id.docas_frmdate_edtx);
        docas_todate_edtx=v.findViewById(R.id.docas_todate_edtx);
        p_type_edtx=v.findViewById(R.id.p_type_edtx);
        d_sbmt_btn=v.findViewById(R.id.d_sbmt_btn);
        d_cancel_btn=v.findViewById(R.id.d_cancel_btn);

        title_txt.setText("Test Suggestion List");

        d_cancel_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                p_type_edtx.setText("");
                patient_frmdate_edtx.setText("");
                patient_todate_edtx.setText("");

                search_text="";
                from_date="";
                to_date="";

                pagecount=1;

                if (InterNetChecker.isNetworkAvailable(getActivity())) {
                    P_TestSugestionsService(getActivity(),pagecount,recordsperpage,from_date,to_date,search_text);
                } else {
                    StoredObjects.ToastMethod(getString(R.string.nointernet), getActivity());
                }
            }
        });

        backbtn_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                fragmentcallinglay( new P_Sub_Member() );
            }
        });

        d_sbmt_btn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                pagecount=1;
                String fromdate=patient_frmdate_edtx.getText().toString().trim();
                String todate=patient_todate_edtx.getText().toString().trim();
                search_text=p_type_edtx.getText().toString().trim();
                from_date=fromdate;
                to_date=todate;

                serviceCalling();

            }
        });
           patient_frmdate_edtx.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                calendar = Calendar.getInstance();
                year = calendar.get(Calendar.YEAR);
                month = calendar.get(Calendar.MONTH);
                dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
                datePickerDialog = new DatePickerDialog(getActivity(),
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int day) {
                                patient_todate_edtx.setText("");
                                patient_frmdate_edtx.setText(StoredObjects.GetSelectedDate(day,month,year));
                            }
                        }, year, month, dayOfMonth);
                datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
                datePickerDialog.show();
            }
        });


        patient_todate_edtx.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                calendar = Calendar.getInstance();
                year = calendar.get(Calendar.YEAR);
                month = calendar.get(Calendar.MONTH);
                dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);
                datePickerDialog = new DatePickerDialog(getActivity(),
                        new DatePickerDialog.OnDateSetListener() {
                            @Override
                            public void onDateSet(DatePicker datePicker, int year, int month, int day) {

                                patient_todate_edtx.setText(StoredObjects.GetSelectedDate(day,month,year));
                            }
                        }, year, month, dayOfMonth);
                datePickerDialog.getDatePicker().setMaxDate(System.currentTimeMillis());
                datePickerDialog.show();
            }
        });


        final LinearLayoutManager linearLayoutManager=new LinearLayoutManager(getActivity());
        p_test_recyler.setLayoutManager(linearLayoutManager);

        p_test_recyler.addOnScrollListener(new RecyclerView.OnScrollListener() {
            @Override
            public void onScrollStateChanged(RecyclerView recyclerView, int newState) {
                super.onScrollStateChanged(recyclerView, newState);

                int lastvisibleitemposition = linearLayoutManager.findLastVisibleItemPosition();

                if (lastvisibleitemposition == adapter.getItemCount() - 1) {

                    pagecount=pagecount+1;
                    if(pagecount<=totalpages){
                        serviceCalling();
                    }

                }
            }
        });



    }



    private void serviceCalling() {

        if (InterNetChecker.isNetworkAvailable(getActivity())) {
            P_TestSugestionsService(getActivity(),pagecount,recordsperpage,from_date,to_date,search_text);
        } else {
            StoredObjects.ToastMethod(getString(R.string.nointernet), getActivity());
        }
    }

    private void P_TestSugestionsService(final Activity activity, final int pagecount, String recordsperpage,String fromdate,String todate,String search_text) {
        if(pagecount==1){
            CustomProgressbar.Progressbarshow(activity);
        }

        APIInterface api = RetrofitInstance.getRetrofitInstance().create(APIInterface.class);
        api.TestSugestions(RetrofitInstance.test_suggestions, StoredObjects.UserId, StoredObjects.UserRoleId,fromdate,todate,pagecount+"",recordsperpage,search_text,"Doctor Suggestions").enqueue(new Callback<ResponseBody>() {
            @Override
            public void onResponse(Call<ResponseBody> call, Response<ResponseBody> response) {

                try {
                    String responseReceived = response.body().string();
                    JSONObject jsonObject = new JSONObject(responseReceived);
                    StoredObjects.LogMethod("response", "response::" + responseReceived);
                    String status = jsonObject.getString("status");
                    if (status.equalsIgnoreCase("200")) {
                        String results = jsonObject.getString("results");
                        String total_pages = jsonObject.getString("total_pages");
                        totalpages=Integer.parseInt(total_pages);

                        if(pagecount==1){
                            data_list.clear();
                            dummy_list = JsonParsing.GetJsonData(results);
                            data_list.addAll(dummy_list);

                            adapter = new HashMapRecycleviewadapter(getActivity(),data_list,"p_tst_sugstn",p_test_recyler,R.layout.p_test_sugtn_lstitem);
                            p_test_recyler.setAdapter(adapter);

                        }else{

                            dummy_list = JsonParsing.GetJsonData(results);
                            data_list.addAll(dummy_list);
                            adapter.notifyDataSetChanged();
                            p_test_recyler.invalidate();
                        }
                        updatelay(data_list);


                    } else {
                        if(pagecount==1){
                            data_list.clear();
                            dummy_list.clear();
                            updatelay(data_list);
                        }

                    }
                } catch (IOException | JSONException e) {
                    e.printStackTrace();
                }

                if(pagecount==1){
                    CustomProgressbar.Progressbarcancel(activity);
                }

            }

            @Override
            public void onFailure(Call<ResponseBody> call, Throwable t) {
                if(pagecount==1){
                    CustomProgressbar.Progressbarcancel(activity);
                }

            }
        });

    }

    public static void updatelay(ArrayList<HashMap<String, String>> data_list) {

        if(data_list.size()==0){
            nodatavailable_txt.setVisibility(View.VISIBLE);
            p_test_recyler.setVisibility(View.GONE);
        }else{
            nodatavailable_txt.setVisibility(View.GONE);
            p_test_recyler.setVisibility(View.VISIBLE);
        }
    }

    public void fragmentcallinglay(Fragment fragment) {
        FragmentManager fragmentManager = getActivity ().getSupportFragmentManager ();
        fragmentManager.beginTransaction ().replace (R.id.frame_container , fragment).commit ();

    }

}
