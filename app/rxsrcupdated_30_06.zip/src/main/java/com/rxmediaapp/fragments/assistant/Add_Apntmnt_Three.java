package com.rxmediaapp.fragments.assistant;

import android.app.Activity;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.rxmediaapp.R;
import com.rxmediaapp.Sidemenu.SideMenu;
import com.rxmediaapp.customadapter.HashMapRecycleviewadapter;
import com.rxmediaapp.customadapter.HashmapViewHolder;
import com.rxmediaapp.serviceparsing.APIInterface;
import com.rxmediaapp.serviceparsing.CustomProgressbar;
import com.rxmediaapp.serviceparsing.InterNetChecker;
import com.rxmediaapp.serviceparsing.JsonParsing;
import com.rxmediaapp.serviceparsing.RetrofitInstance;
import com.rxmediaapp.storedobjects.StoredObjects;

import org.json.JSONException;
import org.json.JSONObject;

import java.io.IOException;
import java.util.ArrayList;
import java.util.HashMap;

import okhttp3.ResponseBody;
import retrofit2.Call;
import retrofit2.Callback;
import retrofit2.Response;


public class Add_Apntmnt_Three extends Fragment {

    ImageView backbtn_img;
    TextView title_txt;
    static RecyclerView p_test_recyler;
    public static TextView nodatavailable_txt;
    public static HashMapRecycleviewadapter adapter;
    public  static ArrayList<HashMap<String, String>> physuggestionslist = new ArrayList<>();
    public  static   HashMapRecycleviewadapter p_adapter;
    @Nullable
    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container, @Nullable Bundle savedInstanceState) {
        View v = inflater.inflate( R.layout.p_test_sugestions,null,false );
        StoredObjects.page_type="ad_apntmnt";
        SideMenu.updatemenu(StoredObjects.page_type);
        initilization(v);
        return v;
    }

    private void initilization(View v) {

        backbtn_img = v.findViewById(R.id.backbtn_img);
        title_txt = v.findViewById(R.id.title_txt);
        p_test_recyler = v.findViewById(R.id.p_test_recyler);
        nodatavailable_txt=v.findViewById(R.id.nodatavailable_txt);
        title_txt.setText("Add Appointment");

        backbtn_img.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                FragmentManager fm = getActivity().getSupportFragmentManager();
                if (fm.getBackStackEntryCount() > 0) {
                    fm.popBackStack();
                }
            }
        });

        final LinearLayoutManager linearLayoutManager=new LinearLayoutManager(getActivity());
        p_test_recyler.setLayoutManager(linearLayoutManager);

        adapter = new HashMapRecycleviewadapter(getActivity(), HashmapViewHolder.p_data_list,"ad_apntmnt",p_test_recyler,R.layout.add_apntmnt_threelst);
        p_test_recyler.setAdapter(adapter);
        physuggestionslist.clear();
        addphysuggestions();

    }
    public static void addphysuggestions() {
        HashMap<String,String> hashMap=new HashMap<>();
        hashMap.put("suggestion_id","");
        hashMap.put("suggestion_value","");
        hashMap.put("suggestion_name","");
        hashMap.put("remove","0");
        physuggestionslist.add(hashMap);
    }



    public void fragmentcallinglay(Fragment fragment) {
        FragmentManager fragmentManager = getActivity ().getSupportFragmentManager ();
        fragmentManager.beginTransaction ().replace (R.id.frame_container , fragment).addToBackStack( "" ).commit ();

    }
}


