package com.rxmediandroidapp.dumpdata;

/**
 * Created by android_2 on 10/11/2018.
 */

public class DumpData {


    public String image;

    public int slidingimg;

}
