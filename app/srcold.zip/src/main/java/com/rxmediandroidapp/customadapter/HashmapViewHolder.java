package com.rxmediandroidapp.customadapter;

import android.app.Activity;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;
import androidx.fragment.app.FragmentManager;
import androidx.recyclerview.widget.RecyclerView;

import com.rxmediandroidapp.R;
import com.rxmediandroidapp.fragments.Add_Apntmnt_Three;
import com.rxmediandroidapp.fragments.doctor.Doc_Patient_List;
import com.rxmediandroidapp.fragments.hospital.H_Profile;

import java.util.ArrayList;
import java.util.HashMap;


class HashmapViewHolder extends RecyclerView.ViewHolder {

    private Activity activity;
    HashMapRecycleviewadapter adapter;

    //p_tst_sugstn
    ImageView p_tst_delete_img;

    //doc_prfle
    LinearLayout d_prf_dctrnme_lay,d_prf_apntmnt_lay;
    ImageView d_prf_up_img,d_prf_down_img;

    //h_patentlst
    LinearLayout h_patnttmngs_lay;

    //ad_apntmnt
    LinearLayout ad_patntlst_lay,ad_patntdtls_lay;
    ImageView ad_patntlst_up_img,ad_patntlst_down_img;

    HashmapViewHolder(View convertView, String type, final Activity activity) {

        super(convertView);
        this.activity = activity;

        if (type.equalsIgnoreCase("home")) {

        }

        else if (type.equalsIgnoreCase("p_tst_sugstn")) {

            p_tst_delete_img = convertView.findViewById(R.id.p_tst_delete_img);
        }

        else if (type.equalsIgnoreCase("h_patentlst")) {

            h_patnttmngs_lay = convertView.findViewById(R.id.h_patnttmngs_lay);
        }


        else if (type.equalsIgnoreCase("ad_apntmnt")) {

            ad_patntlst_lay = convertView.findViewById(R.id.ad_patntlst_lay);
            ad_patntdtls_lay = convertView.findViewById(R.id.ad_patntdtls_lay);
            ad_patntlst_up_img = convertView.findViewById(R.id.ad_patntlst_up_img);
            ad_patntlst_down_img = convertView.findViewById(R.id.ad_patntlst_down_img);
        }

        else if (type.equalsIgnoreCase("doc_prfle")) {

            d_prf_dctrnme_lay = convertView.findViewById(R.id.d_prf_dctrnme_lay);
            d_prf_apntmnt_lay = convertView.findViewById(R.id.d_prf_apntmnt_lay);
            d_prf_up_img = convertView.findViewById(R.id.d_prf_up_img);
            d_prf_down_img = convertView.findViewById(R.id.d_prf_down_img);
        }

    }

    void assign_data(final ArrayList<HashMap<String, String>> datalist, final int position, String formtype) {

        if (formtype.equalsIgnoreCase("home")) {

        }

        else if (formtype.equalsIgnoreCase("p_tst_sugstn")) {

            p_tst_delete_img.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                    fragmentcalling(new H_Profile());

                }
            });
        }

        else if (formtype.equalsIgnoreCase("h_patentlst")) {

            h_patnttmngs_lay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                   // fragmentcalling(new Add_Apntmnt_Three());
                    fragmentcalling(new Doc_Patient_List());

                }
            });
        }


        else if (formtype.equalsIgnoreCase("ad_apntmnt")) {

            if(position==1){
                ad_patntlst_lay.setBackgroundResource(R.drawable.patient_bg_clr);
            }
            ad_patntlst_lay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                   /* if(viewMore.getText().equals("View More")) {
                        ad_patntdtls_lay.setVisibility(View.VISIBLE);
                        ad_patntlst_up_img.setVisibility(View.GONE);
                        ad_patntlst_down_img.setVisibility(View.VISIBLE);
                    }
                    else {
                        ad_patntdtls_lay.setVisibility(View.GONE);
                        ad_patntlst_up_img.setVisibility(View.VISIBLE);
                        ad_patntlst_down_img.setVisibility(View.GONE);

                    }*/
                }
            });
        }

        else if (formtype.equalsIgnoreCase("doc_prfle")) {

            d_prf_dctrnme_lay.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {

                   /* if(viewMore.getText().equals("View More")) {
                        d_prf_apntmnt_lay.setVisibility(View.VISIBLE);
                        d_prf_up_img.setVisibility(View.GONE);
                        d_prf_down_img.setVisibility(View.VISIBLE);
                    }
                    else {
                        d_prf_apntmnt_lay.setVisibility(View.GONE);
                        d_prf_up_img.setVisibility(View.VISIBLE);
                        d_prf_down_img.setVisibility(View.GONE);

                    }*/
                }
            });
        }
    }

    public void fragmentcalling(Fragment fragment) {
        FragmentManager fragmentManager = ((FragmentActivity)activity).getSupportFragmentManager();
        fragmentManager.beginTransaction().replace(R.id.frame_container, fragment).addToBackStack("").commit();
    }

}
